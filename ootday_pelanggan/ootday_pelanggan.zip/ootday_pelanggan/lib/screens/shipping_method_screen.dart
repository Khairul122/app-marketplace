import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ShippingMethodScreen extends StatelessWidget {
  const ShippingMethodScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color maroonColor = Color(0xFF5D1A1A);

    final List<Map<String, dynamic>> shippingMethods = [
      {
        'name': 'Hemat Kargo - SPX Hemat',
        'desc': 'Estimasi tiba: 20 - 25 Okt',
        'price': 10000,
      },
      {
        'name': 'Reguler - J&T Express',
        'desc': 'Estimasi tiba: 18 - 21 Okt',
        'price': 15000,
      },
      {
        'name': 'Reguler - JNE Reg',
        'desc': 'Estimasi tiba: 19 - 22 Okt',
        'price': 14000,
      },
      {
        'name': 'Next Day - JNE YES',
        'desc': 'Estimasi tiba: Besok',
        'price': 25000,
      },
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: maroonColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Pilih Opsi Pengiriman',
          style: GoogleFonts.outfit(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.symmetric(vertical: 20),
        itemCount: shippingMethods.length,
        separatorBuilder: (context, index) => const Divider(),
        itemBuilder: (context, index) {
          final method = shippingMethods[index];
          String priceStr = 'Rp ${method['price'].toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}';
          
          return ListTile(
            onTap: () => Navigator.pop(context, method),
            leading: const Icon(Icons.local_shipping_outlined, color: maroonColor),
            title: Text(method['name'], style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14)),
            subtitle: Text(method['desc'], style: GoogleFonts.outfit(fontSize: 12, color: Colors.grey)),
            trailing: Text(priceStr, style: GoogleFonts.outfit(fontWeight: FontWeight.bold, color: maroonColor)),
          );
        },
      ),
    );
  }
}
