import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'payment_method_screen.dart';
import 'payment_instruction_screen.dart';
import 'order_success_screen.dart';
import 'shipping_method_screen.dart';
import 'address_screen.dart';
import '../utils/order_data.dart';
import '../utils/cart_data.dart';

class CheckoutScreen extends StatefulWidget {
  final List<Map<String, dynamic>> items;
  const CheckoutScreen({super.key, required this.items});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String _selectedPaymentMethod = 'DANA';
  String _selectedShippingName = 'Hemat Kargo - SPX Hemat';
  String _selectedShippingDesc = 'Estimasi tiba: 20 - 25 Okt';
  int _shippingPrice = 10000;
  final Color maroonColor = const Color(0xFF5D1A1A);

  int get _totalPrice {
    return widget.items.fold(0, (sum, item) {
      int price = int.parse(item['price'].toString().replaceAll('.', ''));
      return sum + (price * (item['quantity'] as int));
    });
  }

  @override
  Widget build(BuildContext context) {
    String totalStr = 'Rp ${_totalPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}';

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Color(0xFF5D1A1A)),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            'Checkout',
            style: GoogleFonts.outfit(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Address Section
              _buildSectionTitle('Alamat Pengiriman'),
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const AddressScreen())),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.location_on, color: Color(0xFF5D1A1A), size: 24),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Vanya | (+62) 812 3456 7890', style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14)),
                            const SizedBox(height: 4),
                            Text('jl.Mawar No. 20, RT 05/RW 07, Kel. Cempaka Putih, Muara Satu, Kota Lhokseumawe, Aceh, 12410', 
                                 style: GoogleFonts.outfit(color: Colors.black54, fontSize: 12)),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
                    ],
                  ),
                ),
              ),
              const Divider(height: 40),

              // 2. Products Section
              _buildSectionTitle('Pesanan Anda'),
              ...widget.items.map((item) => _buildProductItem(item)).toList(),
              const Divider(height: 40),

              // 3. Shipping Info Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Opsi Pengiriman', style: GoogleFonts.outfit(fontWeight: FontWeight.w800, fontSize: 15, color: Colors.black)),
                    GestureDetector(
                      onTap: () async {
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const ShippingMethodScreen()),
                        );
                        if (result != null) {
                          setState(() {
                            _selectedShippingName = result['name'];
                            _selectedShippingDesc = result['desc'];
                            _shippingPrice = result['price'];
                          });
                        }
                      },
                      child: Text('Lihat Semua', style: GoogleFonts.outfit(color: maroonColor, fontSize: 13, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () async {
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const ShippingMethodScreen()),
                  );
                  if (result != null) {
                    setState(() {
                      _selectedShippingName = result['name'];
                      _selectedShippingDesc = result['desc'];
                      _shippingPrice = result['price'];
                    });
                  }
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.local_shipping_outlined, color: Color(0xFF5D1A1A), size: 24),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_selectedShippingName, style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14)),
                            Text(_selectedShippingDesc, style: GoogleFonts.outfit(color: Colors.black54, fontSize: 12)),
                          ],
                        ),
                      ),
                      Text('Rp ${_shippingPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}', 
                           style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14)),
                      const SizedBox(width: 10),
                      const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
                    ],
                  ),
                ),
              ),
              const Divider(height: 40),

              // 4. Payment Method
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Metode Pembayaran', style: GoogleFonts.outfit(fontWeight: FontWeight.w800, fontSize: 15, color: Colors.black)),
                    GestureDetector(
                      onTap: () async {
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const PaymentMethodScreen()),
                        );
                        if (result != null) setState(() => _selectedPaymentMethod = result);
                      },
                      child: Text('Lihat Semua', style: GoogleFonts.outfit(color: maroonColor, fontSize: 13, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
              ListTile(
                onTap: () async {
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const PaymentMethodScreen()),
                  );
                  if (result != null) setState(() => _selectedPaymentMethod = result);
                },
                leading: Icon(_getPaymentIcon(), color: const Color(0xFF5D1A1A)),
                title: Text(_selectedPaymentMethod, style: GoogleFonts.outfit(fontSize: 14, fontWeight: FontWeight.bold)),
                trailing: const Icon(Icons.arrow_forward_ios, size: 14),
              ),
              const Divider(height: 40),

              // 4. Order Summary
              _buildSectionTitle('Ringkasan Pembayaran'),
              _buildSummaryRow('Subtotal Produk', totalStr),
              _buildSummaryRow('Biaya Pengiriman', 'Rp ${_shippingPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}'),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Divider(),
              ),
              _buildSummaryRow('Total Pembayaran', 'Rp ${(_totalPrice + _shippingPrice).toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}', isTotal: true),
              const SizedBox(height: 100),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomAction(totalStr),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Text(title, style: GoogleFonts.outfit(fontWeight: FontWeight.w800, fontSize: 15, color: Colors.black)),
    );
  }

  Widget _buildProductItem(Map<String, dynamic> item) {
    String priceStr = 'Rp ${item['price'].toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(item['image']!, width: 70, height: 70, fit: BoxFit.cover),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item['name']!, style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                Text('Varian: ${item['selectedColor'] ?? 'Putih'}, ${item['selectedSize'] ?? 'M'}', style: GoogleFonts.outfit(color: Colors.grey, fontSize: 12)),
                const SizedBox(height: 5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(priceStr, style: GoogleFonts.outfit(fontWeight: FontWeight.bold, color: const Color(0xFF5D1A1A))),
                    Text('x${item['quantity']}', style: GoogleFonts.outfit(color: Colors.grey)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: GoogleFonts.outfit(fontSize: isTotal ? 16 : 13, fontWeight: isTotal ? FontWeight.bold : FontWeight.normal)),
          Text(value, style: GoogleFonts.outfit(fontSize: isTotal ? 18 : 13, fontWeight: FontWeight.bold, color: isTotal ? const Color(0xFF5D1A1A) : Colors.black)),
        ],
      ),
    );
  }

  IconData _getPaymentIcon() {
    if (_selectedPaymentMethod.contains('Bank')) return Icons.account_balance;
    if (_selectedPaymentMethod.contains('COD')) return Icons.handshake;
    return Icons.account_balance_wallet;
  }

  Widget _buildBottomAction(String total) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Colors.black12))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Total Pembayaran', style: GoogleFonts.outfit(fontSize: 12, color: Colors.grey)),
              Text('Rp ${(_totalPrice + _shippingPrice).toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}', 
                   style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.w900, color: const Color(0xFF5D1A1A))),
            ],
          ),
          ElevatedButton(
            onPressed: () {
              // 1. Simpan ke OrderData
              OrderData.addOrder({
                'items': widget.items,
                'totalPrice': _totalPrice + _shippingPrice,
                'paymentMethod': _selectedPaymentMethod,
              });

              // 2. Hapus dari CartData
              for (var item in widget.items) {
                CartData.cartItems.removeWhere((cartItem) => 
                  cartItem['name'] == item['name'] && 
                  cartItem['image'] == item['image']
                );
              }

              // 3. Navigasi Berdasarkan Metode
              if (_selectedPaymentMethod.contains('COD')) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const OrderSuccessScreen()));
              } else {
                Navigator.push(context, MaterialPageRoute(builder: (context) => PaymentInstructionScreen(bankName: _selectedPaymentMethod)));
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: maroonColor,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: Text('Buat Pesanan', style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}
