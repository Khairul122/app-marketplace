import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cart_screen.dart';
import 'checkout_screen.dart';
import '../utils/cart_data.dart';

class ProductDetailScreen extends StatefulWidget {
  final Map<String, String> product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  String _selectedSize = 'M';
  String _selectedColor = 'Denim';
  int _selectedColorIndex = 0;
  int _currentPage = 0;
  int _quantity = 1;
  final PageController _pageController = PageController();

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _showVariantSheet({required String buttonText}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            const Color maroonColor = Color(0xFFB01D1D);
            const Color lightBg = Color(0xFFF8F3F3);

            return Container(
              height: MediaQuery.of(context).size.height * 0.75,
              decoration: const BoxDecoration(
                color: lightBg,
                borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
              ),
              child: Column(
                children: [
                  // 1. Header Section
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                              image: AssetImage(widget.product['image'] ?? 'assets/images/Produk_1.png'),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        const SizedBox(width: 15),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              IconButton(
                                alignment: Alignment.topRight,
                                padding: EdgeInsets.zero,
                                icon: const Icon(Icons.close, color: Colors.black),
                                onPressed: () => Navigator.pop(context),
                              ),
                              Text(
                                'Rp ${widget.product['price']}',
                                style: GoogleFonts.outfit(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.black,
                                ),
                              ),
                              Text(
                                'Stok: 2135',
                                style: GoogleFonts.outfit(
                                  color: Colors.black54, 
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(height: 1),

                  // 2. Content Sections
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 15),
                          Text(
                            'Warna', 
                            style: GoogleFonts.outfit(
                              fontWeight: FontWeight.w800,
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 12,
                            runSpacing: 12,
                            children: {
                              'Denim': const Color(0xFF4B6584),
                              'Coksu': const Color(0xFFD2B48C),
                              'Putih': Colors.white,
                              'Abu-Abu': Colors.grey,
                              'Hitam': Colors.black,
                            }.entries.map((entry) {
                              String c = entry.key;
                              Color colorValue = entry.value;
                              bool isSel = _selectedColor == c;
                              return GestureDetector(
                                onTap: () => setModalState(() => _selectedColor = c),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: isSel ? maroonColor : Colors.grey[400]!, width: 1.5),
                                    borderRadius: BorderRadius.circular(10),
                                    color: isSel ? Colors.white : Colors.transparent,
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        width: 15,
                                        height: 15,
                                        decoration: BoxDecoration(
                                          color: colorValue,
                                          shape: BoxShape.circle,
                                          border: Border.all(color: Colors.grey.withOpacity(0.3), width: 1),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        c, 
                                        style: GoogleFonts.outfit(
                                          color: isSel ? maroonColor : Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 25),
                          const Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Ukuran', 
                                style: GoogleFonts.outfit(
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black,
                                  fontSize: 15,
                                ),
                              ),
                              Text(
                                'Tabel Ukuran >', 
                                style: GoogleFonts.outfit(
                                  color: Colors.black54, 
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: ['M', 'L', 'XL'].map((s) {
                              bool isSel = _selectedSize == s;
                              return GestureDetector(
                                onTap: () => setModalState(() => _selectedSize = s),
                                child: Container(
                                  margin: const EdgeInsets.only(right: 12),
                                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: isSel ? maroonColor : Colors.grey[400]!, width: 1.5),
                                    borderRadius: BorderRadius.circular(10),
                                    color: isSel ? Colors.white : Colors.transparent,
                                  ),
                                  child: Text(
                                    s, 
                                    style: GoogleFonts.outfit(
                                      color: isSel ? maroonColor : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 25),
                          const Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Jumlah', 
                                style: GoogleFonts.outfit(
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black,
                                  fontSize: 15,
                                ),
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey[400]!, width: 1.2),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  children: [
                                    IconButton(
                                      icon: const Icon(Icons.remove, size: 18, color: Colors.black),
                                      onPressed: () {
                                        if (_quantity > 1) {
                                          setModalState(() {
                                            _quantity--;
                                          });
                                        }
                                      },
                                    ),
                                    Text(
                                      '$_quantity', 
                                      style: GoogleFonts.outfit(
                                        fontWeight: FontWeight.w900,
                                        fontSize: 16,
                                        color: Colors.black,
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.add, size: 18, color: Colors.black),
                                      onPressed: () {
                                        setModalState(() {
                                          _quantity++;
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 30),
                        ],
                      ),
                    ),
                  ),

                  // 3. Confirm Button (Dynamic Text)
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        if (buttonText == 'Beli Sekarang') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CheckoutScreen(items: [
                                {
                                  'name': widget.product['name'],
                                  'price': widget.product['price'],
                                  'selectedColor': _selectedColor,
                                  'selectedSize': _selectedSize,
                                  'quantity': _quantity,
                                  'image': widget.product['image'],
                                }
                              ]),
                            ),
                          );
                        } else {
                          CartData.addItem({
                            'name': widget.product['name'],
                            'price': widget.product['price'],
                            'selectedColor': _selectedColor,
                            'selectedSize': _selectedSize,
                            'quantity': _quantity,
                            'image': widget.product['image'],
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Berhasil ditambahkan ke keranjang!'),
                              backgroundColor: maroonColor,
                            ),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: maroonColor,
                        minimumSize: const Size(double.infinity, 55),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text(
                        buttonText,
                        style: GoogleFonts.outfit(
                          color: Colors.white, 
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildColorOption(BuildContext context, String label, bool isSelected) {
    return Container(
      width: 130,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isSelected ? const Color(0xFFB01D1D) : Colors.grey[300]!,
          width: isSelected ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 35,
            height: 35,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              image: DecorationImage(
                image: AssetImage(widget.product['image'] ?? 'assets/images/Produk_1.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              style: GoogleFonts.outfit(
                fontSize: 13, 
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                color: Colors.black,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color maroonColor = Color(0xFF5D1A1A);
    const Color lightBg = Color(0xFFF3F3F3);

    String priceString = widget.product['price'] ?? '0';
    String formattedPrice = 'Rp ${priceString.replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}';

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark, // Ikon Hitam
        statusBarBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image Carousel Section
            Stack(
              children: [
                SizedBox(
                  height: 450,
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: (index) => setState(() => _currentPage = index),
                    itemCount: 6,
                    itemBuilder: (context, index) {
                      return Hero(
                        tag: index == 0 ? (widget.product['id'] ?? 'product_${widget.product['name']}') : 'img_$index',
                        child: Image.asset(widget.product['image'] ?? 'assets/images/Produk_1.png', width: double.infinity, height: 450, fit: BoxFit.cover),
                      );
                    },
                  ),
                ),
                Positioned(
                  bottom: 20,
                  right: 20,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(15)),
                    child: Text('${_currentPage + 1}/6', style: GoogleFonts.outfit(color: Colors.white, fontSize: 12)),
                  ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildCircleButton(Icons.arrow_back, () => Navigator.pop(context)),
                        Row(
                          children: [
                            _buildCircleButton(Icons.share_outlined, () {}),
                            const SizedBox(width: 10),
                            _buildCircleButton(Icons.shopping_cart_outlined, () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const CartScreen()),
                              );
                            }),
                            const SizedBox(width: 10),
                            _buildCircleButton(Icons.more_vert, () {}),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Pricing & Title
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(formattedPrice, style: GoogleFonts.outfit(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.black)),
                      Row(
                        children: [
                          Text('${widget.product['sold'] ?? '10RB+'} Terjual', style: GoogleFonts.outfit(color: Colors.grey, fontSize: 14)),
                          const SizedBox(width: 10),
                          const Icon(Icons.favorite_border, color: Colors.black, size: 24),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  Text(widget.product['name'] ?? 'Produk Ootday', style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.black, height: 1.3)),
                ],
              ),
            ),

            // Variant - Warna
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Warna', style: GoogleFonts.outfit(fontSize: 16, color: Colors.black, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 70,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: 6,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedColorIndex = index;
                              _pageController.animateToPage(index, duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.only(right: 12),
                            width: 70,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _selectedColorIndex == index ? maroonColor : Colors.grey.withOpacity(0.3), width: 2),
                              image: DecorationImage(image: AssetImage(widget.product['image'] ?? 'assets/images/Produk_1.png'), fit: BoxFit.cover),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // Variant - Ukuran
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Ukuran', style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.black)),
                  const SizedBox(height: 12),
                  Row(
                    children: ['M', 'L', 'XL'].map((size) {
                      bool isSelected = _selectedSize == size;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedSize = size),
                        child: Container(
                          margin: const EdgeInsets.only(right: 15),
                          padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 8),
                          decoration: BoxDecoration(
                            color: isSelected ? maroonColor.withOpacity(0.1) : lightBg,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: isSelected ? maroonColor : Colors.transparent),
                          ),
                          child: Text(size, style: GoogleFonts.outfit(fontWeight: FontWeight.bold, color: isSelected ? maroonColor : Colors.black87)),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // Description Box
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(color: lightBg.withOpacity(0.5), borderRadius: BorderRadius.circular(15)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Deskripsi Produk', style: GoogleFonts.outfit(fontWeight: FontWeight.w800, fontSize: 14, color: Colors.black)),
                    const SizedBox(height: 8),
                    Text(
                      'Didesain dengan pita manis di bagian leher dan potongan longgar elegan, cocok untuk kamu yang ingin tampil rapi, modern, dan nyaman di segala suasana — baik ke kantor, kuliah, maupun acara santai.\n\n✨ Detail Produk:\n• Warna: Sesuai pilihan\n• Model: Lengan panjang, kerah klasik\n• Bahan: Polyester halus, ringan, dan tidak mudah kusut\n• Ukuran: M - XL',
                      style: GoogleFonts.outfit(fontSize: 13, color: Colors.black, height: 1.5),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 100),
          ],
        ),
      ),
      
      bottomSheet: Container(
        height: 85,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(color: lightBg, borderRadius: const BorderRadius.vertical(top: Radius.circular(30)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, -5))]),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              child: Image.asset(
                'assets/images/icons msg.png',
                width: 28,
                height: 28,
                color: const Color(0xFF5D1A1A),
              ),
            ),
            const SizedBox(width: 10),
            Container(width: 1, height: 30, color: Colors.grey.withOpacity(0.3)),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: () => _showVariantSheet(buttonText: 'masukkan keranjang'),
              child: _buildActionIcon(Icons.add_shopping_cart),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: GestureDetector(
                onTap: () => _showVariantSheet(buttonText: 'Beli Sekarang'),
                child: Container(
                  height: 55,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.grey.withOpacity(0.2))),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Beli Dengan Harga', style: GoogleFonts.outfit(fontSize: 12, color: Colors.black)),
                        Text(formattedPrice, style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }

  Widget _buildCircleButton(IconData icon, VoidCallback onTap) {
    return GestureDetector(onTap: onTap, child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), shape: BoxShape.circle), child: Icon(icon, color: Colors.white, size: 20)));
  }

  Widget _buildActionIcon(IconData icon) {
    return Container(padding: const EdgeInsets.all(12), child: Icon(icon, color: const Color(0xFF5D1A1A), size: 28));
  }
}
