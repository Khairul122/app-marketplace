import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'order_success_screen.dart';

class PaymentInstructionScreen extends StatefulWidget {
  final String bankName;
  const PaymentInstructionScreen({super.key, required this.bankName});

  @override
  State<PaymentInstructionScreen> createState() => _PaymentInstructionScreenState();
}

class _PaymentInstructionScreenState extends State<PaymentInstructionScreen> {
  bool _isExpanded = true;
  final Color maroonColor = const Color(0xFF5D1A1A);

  // 1. Fungsi Pop-up Sukses
  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(30),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  'assets/images/pymt_done.png',
                  width: 120,
                  height: 120,
                  errorBuilder: (c, e, s) => Icon(Icons.check_circle_outline, size: 80, color: maroonColor),
                ),
                const SizedBox(height: 20),
                Text(
                  'Pembayaran berhasil',
                  style: GoogleFonts.outfit(color: maroonColor, fontSize: 20, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  'Yey, pembayaran berhasil\nPesanan akan segera dibuat',
                  style: GoogleFonts.outfit(color: maroonColor.withOpacity(0.7), fontSize: 13),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 30),
                // Tombol OK yang mengarah ke OrderSuccessScreen
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Tutup Dialog
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const OrderSuccessScreen()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: maroonColor,
                    minimumSize: const Size(double.infinity, 45),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text('OK', style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color tealColor = Color(0xFF00BFA5);
    const Color vaColor = Color(0xFFD32F2F);

    String logoPath = 'assets/images/bank/bsi.png';
    String vaNumber = '600 0853 6198 3126';
    
    if (widget.bankName.contains('Mandiri')) {
      logoPath = 'assets/images/bank/mandiri.png';
      vaNumber = '889 0853 6198 3126';
    } else if (widget.bankName.contains('BRI')) {
      logoPath = 'assets/images/bank/bri.png';
      vaNumber = '123 0853 6198 3126';
    } else if (widget.bankName.contains('Aceh')) {
      logoPath = 'assets/images/bank/aceh.png';
      vaNumber = '700 0853 6198 3126';
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Color.fromARGB(255, 166, 15, 15)),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            'Pembayaran',
            style: GoogleFonts.outfit(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Image.asset(logoPath, width: 40, height: 40, errorBuilder: (c, e, s) => Icon(Icons.account_balance, size: 40, color: tealColor)),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Text(
                        widget.bankName,
                        style: GoogleFonts.outfit(fontSize: 15, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('No. Rek/Virtual Account', style: GoogleFonts.outfit(color: Colors.black54, fontSize: 13)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          vaNumber,
                          style: GoogleFonts.outfit(color: vaColor, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1.2),
                        ),
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: vaNumber.replaceAll(' ', '')));
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Nomor VA ${widget.bankName} disalin!')));
                          },
                          child: Text('Salin', style: GoogleFonts.outfit(color: tealColor, fontWeight: FontWeight.bold, fontSize: 14)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Proses verifikasi kurang dari 10 menit setelah pembayaran berhasil', style: GoogleFonts.outfit(color: tealColor, fontSize: 13, fontWeight: FontWeight.w500)),
                    const SizedBox(height: 15),
                    Text('Bayar pesanan ke Virtual Account di atas sebelum membuat pesanan kembali dengan Virtual Account agar nomor tetap sama.', style: GoogleFonts.outfit(color: Colors.black87, fontSize: 13, height: 1.5)),
                  ],
                ),
              ),
              Container(height: 10, color: Colors.grey[200]),
              GestureDetector(
                onTap: () => setState(() => _isExpanded = !_isExpanded),
                child: Container(
                  color: Colors.transparent,
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      RichText(
                        text: TextSpan(
                          style: GoogleFonts.outfit(color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                          children: [
                            const TextSpan(text: 'Petunjuk Transfer mBankir '),
                            TextSpan(text: 'Ootday', style: GoogleFonts.outfit(color: maroonColor)),
                          ],
                        ),
                      ),
                      Icon(_isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: Colors.black54),
                    ],
                  ),
                ),
              ),
              const Divider(height: 1),
              if (_isExpanded)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Column(
                    children: [
                      _buildStepRow(1, 'Pilih Pembayaran.'),
                      _buildStepRow(2, 'Pilih E-commerce > Ootday.'),
                      _buildStepRow(3, 'Pilih nomor rekening yang akan kamu gunakan.'),
                      _buildStepRow(4, 'Masukkan nomor Virtual Account $vaNumber, dan klik Selanjutnya.'),
                      _buildStepRow(5, 'Masukkan PIN Anda dan klik Selanjutnya.'),
                    ],
                  ),
                ),
              const SizedBox(height: 50),
              // Tombol OK di halaman yang memicu Pop-up
              Padding(
                padding: const EdgeInsets.all(20),
                child: ElevatedButton(
                  onPressed: _showSuccessDialog,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: maroonColor,
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text('OK', style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStepRow(int number, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: const BoxDecoration(color: Colors.grey, shape: BoxShape.circle),
            child: Center(child: Text('$number', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 15),
          Expanded(child: Text(text, style: GoogleFonts.outfit(fontSize: 14, color: Colors.black87, height: 1.4))),
        ],
      ),
    );
  }
}
