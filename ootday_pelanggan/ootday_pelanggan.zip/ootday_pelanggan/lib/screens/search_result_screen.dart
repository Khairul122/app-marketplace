import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'product_detail_screen.dart';

class SearchResultScreen extends StatefulWidget {
  final String searchQuery;
  const SearchResultScreen({super.key, required this.searchQuery});

  @override
  State<SearchResultScreen> createState() => _SearchResultScreenState();
}

class _SearchResultScreenState extends State<SearchResultScreen> {
  String _selectedCategory = 'Terkait';
  String _priceSort = 'none'; // 'none', 'asc', 'desc'
  late TextEditingController _searchController;
  late String _currentQuery;

  @override
  void initState() {
    super.initState();
    _currentQuery = widget.searchQuery;
    _searchController = TextEditingController(text: _currentQuery);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _togglePriceSort() {
    setState(() {
      if (_priceSort == 'none') {
        _priceSort = 'asc';
      } else if (_priceSort == 'asc') {
        _priceSort = 'desc';
      } else {
        _priceSort = 'none';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    const Color maroonColor = Color(0xFF5D1A1A);
    const Color bgColor = Color(0xFFF8F3F3);

    // Logika Pencarian Dinamis
    String query = _currentQuery.toLowerCase();
    bool isPria = query.contains('pria');
    bool isWanita = query.contains('wanita');
    bool isRok = query.contains('rok');
    bool isCelana = query.contains('celana');
    bool isKemeja = query.contains('kemeja');
    
    // Logika penentuan apa yang ditampilkan
    bool showKemejaWanita = isWanita || (isKemeja && !isPria && !isWanita && !isRok && !isCelana);
    bool showKemejaPria = isPria || (isKemeja && !isPria && !isWanita && !isRok && !isCelana);
    bool showRok = isRok;
    bool showCelana = isCelana;

    bool isProductFound = showKemejaWanita || showKemejaPria || showRok || showCelana;

    // Menghasilkan produk berdasarkan kategori
    List<Map<String, String>> results = [];
    if (isProductFound) {
      if (showKemejaWanita) {
        results.addAll(List.generate(20, (index) {
          int id = index + 1;
          return {
            'id': 'w_$id',
            'name': 'Kemeja Wanita Elegan Style $id',
            'image': 'assets/images/kemeja_wanita/$id.jpeg',
            'price': '${100000 + (id * 5000)}',
            'rating': (4.5 + (id % 6) * 0.1).toStringAsFixed(1),
            'sold': (50 + ((id * 37) % 200)).toString(),
          };
        }));
      }
      if (showKemejaPria) {
        results.addAll(List.generate(5, (index) {
          int id = index + 1;
          return {
            'id': 'p_$id',
            'name': 'Kemeja Pria Exclusive $id',
            'image': 'assets/images/kemeja_pria/$id.jpeg',
            'price': '${150000 + (id * 10000)}',
            'rating': (4.7 + (id % 4) * 0.1).toStringAsFixed(1),
            'sold': (30 + (id * 25)).toString(),
          };
        }));
      }
      if (showRok) {
        results.addAll(List.generate(6, (index) {
          int id = index + 1;
          return {
            'id': 'r_$id',
            'name': 'Rok Cantik Koleksi $id',
            'image': 'assets/images/Rok/$id.jpeg',
            'price': '${120000 + (id * 8000)}',
            'rating': (4.6 + (id % 5) * 0.1).toStringAsFixed(1),
            'sold': (40 + (id * 15)).toString(),
          };
        }));
      }
      if (showCelana) {
        // Celana Cewe
        results.addAll(List.generate(3, (index) {
          int id = index + 1;
          return {
            'id': 'clw_$id',
            'name': 'Celana Trendy Wanita Style $id',
            'image': 'assets/images/celana/cewe$id.jpeg',
            'price': '${150000 + (id * 12000)}',
            'rating': '4.9',
            'sold': '${100 + (id * 20)}',
          };
        }));
        // Celana Cowo
        results.addAll(List.generate(3, (index) {
          int id = index + 1;
          return {
            'id': 'clp_$id',
            'name': 'Celana Casual Pria Style $id',
            'image': 'assets/images/celana/cowo$id.jpeg',
            'price': '${175000 + (id * 15000)}',
            'rating': '4.8',
            'sold': '${80 + (id * 15)}',
          };
        }));
      }
    }

    // Logika Pengurutan
    List<Map<String, String>> sortedResults = List.from(results);
    if (_selectedCategory == 'Terbaru') {
      sortedResults = sortedResults.reversed.toList();
    } else if (_selectedCategory == 'Terlaris') {
      sortedResults.sort((a, b) => int.parse(b['sold']!).compareTo(int.parse(a['sold']!)));
    } else if (_selectedCategory == 'Harga') {
      if (_priceSort == 'asc') {
        sortedResults.sort((a, b) => int.parse(a['price']!).compareTo(int.parse(b['price']!)));
      } else if (_priceSort == 'desc') {
        sortedResults.sort((a, b) => int.parse(b['price']!).compareTo(int.parse(a['price']!)));
      }
    }

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // Top Bar
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.arrow_back, color: maroonColor, size: 24),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Container(
                      height: 45,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.search, color: maroonColor.withOpacity(0.5), size: 20),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextField(
                              controller: _searchController,
                              textInputAction: TextInputAction.search,
                              onSubmitted: (value) {
                                if (value.isNotEmpty) {
                                  setState(() {
                                    _currentQuery = value;
                                  });
                                }
                              },
                              style: GoogleFonts.outfit(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 13),
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                          ),
                          Icon(Icons.photo_camera_outlined, color: maroonColor.withOpacity(0.5), size: 20),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: maroonColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.tune, size: 20, color: Colors.white),
                  ),
                ],
              ),
            ),

            // Filter Bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildFilterTab('Terkait', maroonColor),
                  _buildFilterTab('Terbaru', maroonColor),
                  _buildFilterTab('Terlaris', maroonColor),
                  _buildFilterTab('Harga', maroonColor),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Results Grid atau Empty State
            Expanded(
              child: isProductFound
                  ? GridView.builder(
                      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 30),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.65,
                      ),
                      itemCount: sortedResults.length,
                      itemBuilder: (context, index) {
                        return _buildResultCard(sortedResults[index], maroonColor);
                      },
                    )
                  : Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.search_off_rounded,
                            size: 80,
                            color: maroonColor.withOpacity(0.3),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Produk Tidak Ditemukan',
                            style: GoogleFonts.outfit(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: maroonColor,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Maaf, "${_currentQuery}" saat ini belum tersedia.',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.outfit(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterTab(String label, Color maroonColor) {
    bool isActive = _selectedCategory == label;
    bool isPrice = label == 'Harga';
    
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedCategory = label;
          if (isPrice) {
            _togglePriceSort();
          } else {
            _priceSort = 'none';
          }
        });
      },
      child: Column(
        children: [
          Row(
            children: [
              Text(
                label,
                style: GoogleFonts.outfit(
                  fontSize: 14,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.w400,
                  color: isActive ? maroonColor : Colors.grey,
                ),
              ),
              if (isPrice) ...[
                const SizedBox(width: 4),
                Column(
                  children: [
                    Icon(
                      Icons.keyboard_arrow_up,
                      size: 12,
                      color: _priceSort == 'asc' ? maroonColor : Colors.grey,
                    ),
                    Transform.translate(
                      offset: const Offset(0, -6),
                      child: Icon(
                        Icons.keyboard_arrow_down,
                        size: 12,
                        color: _priceSort == 'desc' ? maroonColor : Colors.grey,
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
          const SizedBox(height: 4),
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            height: 2,
            width: isActive ? 20 : 0,
            color: maroonColor,
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard(Map<String, String> product, Color maroonColor) {
    String priceString = product['price']!;
    String formattedPrice = 'Rp ${priceString.replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}';

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailScreen(product: product),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              child: Image.asset(
                product['image']!,
                fit: BoxFit.cover,
                width: double.infinity,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product['name']!,
                  maxLines: 2,
                  overflow: TextOverflow.visible,
                  style: GoogleFonts.outfit(
                    fontSize: 14, 
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  formattedPrice,
                  style: GoogleFonts.outfit(fontSize: 14, color: maroonColor, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.amber, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      product['rating']!,
                      style: GoogleFonts.outfit(fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 1,
                      height: 10,
                      color: Colors.grey.withOpacity(0.5),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${product['sold']} Terjual',
                      style: GoogleFonts.outfit(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      ),
    );
  }
}
