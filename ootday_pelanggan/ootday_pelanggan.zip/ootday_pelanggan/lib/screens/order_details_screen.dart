import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:ootday_pelanggan/screens/cart_screen.dart';
import 'chat_list_screen.dart';
import 'cancellation_details_screen.dart';

class OrderDetailsScreen extends StatelessWidget {
  const OrderDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color maroonColor = Color(0xFF5D1A1A);
    const Color lightPinkBg = Color(0xFFF8F3F3);

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: maroonColor),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            'Rincian Pesanan',
            style: GoogleFonts.outfit(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
          ),
          actions: [
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const CartScreen())),
              child: Padding(
                padding: const EdgeInsets.only(right: 20, top: 10),
                child: Stack(
                  children: [
                    const Icon(Icons.shopping_cart_outlined, color: maroonColor, size: 28),
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(color: maroonColor, shape: BoxShape.circle),
                        constraints: const BoxConstraints(minWidth: 14, minHeight: 14),
                        child: const Text('3', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Estimation Banner
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                color: lightPinkBg,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Estimasi Tiba: 20 - 25 Okt',
                      style: GoogleFonts.outfit(color: maroonColor, fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Pesanan Anda Sedang Disiapkan',
                      style: GoogleFonts.outfit(color: Colors.black87, fontSize: 13),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 20),
              
              // 2. Info Pengiriman
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Info Pengiriman', style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 15)),
                    const SizedBox(height: 15),
                    Row(
                      children: [
                        const Icon(Icons.inventory_2, color: maroonColor, size: 30),
                        const SizedBox(width: 15),
                        Text('Hemat Kargo - SPX Hemat', style: GoogleFonts.outfit(fontSize: 14)),
                      ],
                    ),
                  ],
                ),
              ),
              
              const Divider(height: 40),
              
              // 3. Alamat Pengiriman
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Alamat Pengiriman', style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 15)),
                    const SizedBox(height: 15),
                    Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: lightPinkBg,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.location_on, color: maroonColor, size: 24),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Vanya (+62) 812-3456-7890',
                                  style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  'jl.Mawar No. 20, RT 05/RW 07, Kel. Cempaka Putih, Muara Satu, Kota Lhokseumawe, Nanggroe Aceh Darussalam, ID 12410',
                                  style: GoogleFonts.outfit(fontSize: 12, color: Colors.black54, height: 1.4),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.black38),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              const Divider(height: 40),
              
              // 4. Order Card
              _buildOrderCard(context, maroonColor),
              
              const Divider(height: 40),
              
              // 5. Additional Info Section
              _buildInfoSection(maroonColor),
              
              const SizedBox(height: 120), // Space for bottom buttons
            ],
          ),
        ),
        bottomSheet: _buildBottomButtons(context, maroonColor),
      ),
    );
  }

  Widget _buildOrderCard(BuildContext context, Color maroonColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.storefront_outlined, size: 20, color: Colors.black),
              const SizedBox(width: 10),
              Text('Ootday Fashion Store', style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset('assets/images/kemeja_wanita/3.jpeg', width: 70, height: 70, fit: BoxFit.cover),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Wide Collar Drawstring Sleeve Blouse',
                      style: GoogleFonts.outfit(fontSize: 13, fontWeight: FontWeight.w500),
                      maxLines: 2,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Putih, M', style: GoogleFonts.outfit(fontSize: 11, color: Colors.grey)),
                        Text('x1', style: GoogleFonts.outfit(fontSize: 12, color: Colors.grey)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          Align(
            alignment: Alignment.centerRight,
            child: Text('Total 1 Produk: Rp95.000', style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14)),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoSection(Color maroonColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.help_outline, color: Color(0xFF5D1A1A), size: 22),
              const SizedBox(width: 10),
              Expanded(child: Text('Pusat Bantuan', style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 14))),
              const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.black38),
            ],
          ),
          const Divider(height: 30),
          _buildTextRowWithCopy('No. Pesanan', '251011SWQ4983G'),
          const Divider(height: 30),
          _buildTextRow('Metode Pembayaran', 'DANA', icon: Icons.account_balance_wallet, iconColor: Colors.blue),
          const Divider(height: 30),
          _buildTextRow('Waktu Pemesanan', '11-10-2025 21:20'),
        ],
      ),
    );
  }

  Widget _buildTextRow(String label, String value, {IconData? icon, Color? iconColor}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: GoogleFonts.outfit(color: Colors.black87, fontSize: 13)),
        Row(
          children: [
            if (icon != null) ...[
              Icon(icon, size: 18, color: iconColor),
              const SizedBox(width: 5),
            ],
            Text(value, style: GoogleFonts.outfit(color: Colors.black87, fontSize: 13, fontWeight: FontWeight.w500)),
          ],
        ),
      ],
    );
  }

  Widget _buildTextRowWithCopy(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: GoogleFonts.outfit(color: Colors.black87, fontSize: 13)),
        Row(
          children: [
            Text(value, style: GoogleFonts.outfit(color: Colors.black87, fontSize: 13, fontWeight: FontWeight.w500)),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(border: Border.all(color: Colors.black26), borderRadius: BorderRadius.circular(20)),
              child: Text('Salin', style: GoogleFonts.outfit(fontSize: 10)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSmallOutlinedButton(String label, VoidCallback onTap) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        side: BorderSide(color: Colors.grey.shade300),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.symmetric(horizontal: 15),
      ),
      child: Text(label, style: GoogleFonts.outfit(color: Colors.black87, fontSize: 12, fontWeight: FontWeight.w500)),
    );
  }

  Widget _buildBottomButtons(BuildContext context, Color maroonColor) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Colors.black12))),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: maroonColor,
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: Text('Batalkan Pesanan', style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const ChatListScreen())),
              style: ElevatedButton.styleFrom(
                backgroundColor: maroonColor,
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: Text('Hubungi Penjual', style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}
