import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class PaymentMethodScreen extends StatefulWidget {
  const PaymentMethodScreen({super.key});

  @override
  State<PaymentMethodScreen> createState() => _PaymentMethodScreenState();
}

class _PaymentMethodScreenState extends State<PaymentMethodScreen> {
  String _selectedMethod = 'Bank BRI';

  @override
  Widget build(BuildContext context) {
    const Color maroonColor = Color(0xFF5D1A1A);
    const Color lightBg = Color(0xFFF3F0F0);

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: lightBg,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: maroonColor),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            'Metode Pembayaran',
            style: GoogleFonts.outfit(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 0. COD Section
                    _buildSectionHeader('Bayar di Tempat', Icons.payments_outlined),
                    _buildPaymentItem('COD (Bayar di Tempat)', null, icon: Icons.handshake_outlined),
                    
                    const SizedBox(height: 10),

                    // 1. Transfer Bank Section
                    _buildSectionHeader('Transfer Bank', Icons.swap_horiz_rounded),
                    _buildPaymentItem('Bank BRI', 'assets/images/bank/bri.png'),
                    _buildPaymentItem('Bank Mandiri', 'assets/images/bank/mandiri.png'),
                    _buildPaymentItem('Bank Aceh Syariah', 'assets/images/bank/aceh.png'),
                    _buildPaymentItem('Bank Syariah Indonesia (BSI)', 'assets/images/bank/bsi.png'),
                    _buildPaymentItem('Bank Lainnya', null, icon: Icons.account_balance),
                    
                    const SizedBox(height: 20),
                    
                    // 2. E-Wallet Section
                    _buildSectionHeader('E-Wallet', Icons.account_balance_wallet_outlined),
                    _buildPaymentItem('DANA', 'assets/images/bank/dana.png'),
                    _buildPaymentItem('GOPAY', 'assets/images/bank/gopay.png'),
                    _buildPaymentItem('OVO', 'assets/images/bank/ovo.png'),
                    
                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
            
            // Confirm Button
            Padding(
              padding: const EdgeInsets.all(20),
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context, _selectedMethod),
                style: ElevatedButton.styleFrom(
                  backgroundColor: maroonColor,
                  minimumSize: const Size(double.infinity, 55),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: Text(
                  'KONFIRMASI',
                  style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: Colors.grey[400], shape: BoxShape.circle),
            child: Icon(icon, color: Colors.black, size: 20),
          ),
          const SizedBox(width: 15),
          Text(title, style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(width: 5),
          const Icon(Icons.help_outline, size: 18, color: Colors.black54),
        ],
      ),
    );
  }

  Widget _buildPaymentItem(String name, String? imagePath, {IconData? icon}) {
    bool isSelected = _selectedMethod == name;
    
    return GestureDetector(
      onTap: () => setState(() => _selectedMethod = name),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 1),
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.white.withOpacity(0.5),
          border: Border(bottom: BorderSide(color: Colors.grey.shade300, width: 0.5)),
        ),
        child: Row(
          children: [
            Container(
              width: 45,
              height: 30,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
              ),
              child: imagePath != null 
                ? Image.asset(imagePath, fit: BoxFit.contain, 
                    errorBuilder: (context, error, stackTrace) => Icon(icon ?? Icons.payment, color: Colors.black87),
                  )
                : Icon(icon ?? Icons.payment, color: Colors.black87),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Text(
                name, 
                style: GoogleFonts.outfit(
                  fontSize: 14, 
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                  color: isSelected ? Colors.black : Colors.black87,
                )
              ),
            ),
            Icon(
              isSelected ? Icons.check_circle : Icons.arrow_forward_ios, 
              size: 16, 
              color: isSelected ? const Color(0xFF5D1A1A) : Colors.black26,
            ),
          ],
        ),
      ),
    );
  }
}
