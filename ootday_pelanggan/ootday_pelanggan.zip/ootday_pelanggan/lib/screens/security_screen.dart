import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'chat_list_screen.dart';

class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});

  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> {
  String? _userPhone;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  // Fungsi untuk mengambil data tambahan user dari Firestore
  Future<void> _fetchUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
        if (doc.exists && doc.data() != null) {
          setState(() {
            _userPhone = doc.data()!['phone'] as String?;
            _isLoading = false;
          });
        } else {
          setState(() => _isLoading = false);
        }
      } catch (e) {
        print('Error fetching user data: $e');
        setState(() => _isLoading = false);
      }
    } else {
      setState(() => _isLoading = false);
    }
  }

  // Fungsi untuk mengirim email reset password
  Future<void> _resetPassword(BuildContext context, String? email) async {
    if (email == null || email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Email tidak ditemukan')),
      );
      return;
    }

    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      if (context.mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Email Terkirim', style: GoogleFonts.outfit(fontWeight: FontWeight.bold)),
            content: Text(
              'Link atur ulang password telah dikirim ke $email. Silakan periksa kotak masuk atau spam email Anda.',
              style: GoogleFonts.outfit(),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK', style: TextStyle(color: Color(0xFF5D1A1A))),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal mengirim email: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    const Color maroonColor = Color(0xFF5D1A1A);
    const Color headerBg = Color(0xFFD9D9D9);
    
    final user = FirebaseAuth.instance.currentUser;
    final String userEmail = user?.email ?? 'Tidak ada email';
    
    // Masking phone number
    String displayPhone = _userPhone ?? 'Belum Ditambahkan';
    if (_userPhone != null && _userPhone!.length > 4) {
       displayPhone = '${_userPhone!.substring(0, 4)}******${_userPhone!.substring(_userPhone!.length - 2)}';
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: headerBg,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: maroonColor),
            onPressed: () => Navigator.pop(context),
          ),
          centerTitle: true,
          title: Text(
            'Pengaturan Akun',
            style: GoogleFonts.outfit(
              color: Colors.black87,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 15),
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const ChatListScreen())),
                child: Image.asset(
                  'assets/images/icons msg.png',
                  width: 26,
                  height: 26,
                  color: maroonColor,
                ),
              ),
            ),
          ],
        ),
        body: _isLoading 
          ? const Center(child: CircularProgressIndicator(color: maroonColor))
          : Column(
              children: [
                const SizedBox(height: 10),
                _buildSecurityTile(
                  'Atur Ulang Password', 
                  trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.black54),
                  onTap: () => _resetPassword(context, user?.email),
                ),
                _buildSecurityTile(
                  'Alamat Email', 
                  value: userEmail, 
                  valueColor: Colors.blue.withOpacity(0.3)
                ),
                _buildSecurityTile('No. Telp', value: displayPhone),
              ],
            ),
      ),
    );
  }

  Widget _buildSecurityTile(String title, {Widget? trailing, String? value, Color? valueColor, VoidCallback? onTap}) {
    return Column(
      children: [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
          title: Text(
            title,
            style: GoogleFonts.outfit(fontSize: 14, color: Colors.black87),
          ),
          trailing: trailing ?? (value != null ? Text(
            value,
            style: GoogleFonts.outfit(
              fontSize: 14, 
              color: valueColor ?? Colors.black26,
              decoration: valueColor != null ? TextDecoration.underline : null,
            ),
          ) : null),
          onTap: onTap ?? () {},
        ),
        const Divider(height: 1, indent: 20, endIndent: 20, color: Colors.black12),
      ],
    );
  }
}
