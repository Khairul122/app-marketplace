import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'chat_detail_screen.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color maroonColor = Color(0xFF5D1A1A);
    const Color bgColor = Color(0xFFF8F3F3);

    final List<Map<String, String>> chats = [
      {
        'name': 'Ootday Official Store',
        'lastMessage': 'Halo kak, stok kemeja putih ready ya...',
        'time': '10:30',
        'unread': '2',
        'image': 'assets/images/profile.png'
      },
      {
        'name': 'Fashionista Shop',
        'lastMessage': 'Terima kasih sudah berbelanja!',
        'time': 'Kemarin',
        'unread': '0',
        'image': 'assets/images/profile.png'
      },
      {
        'name': 'Modern Wear ID',
        'lastMessage': 'Pesanan Anda sedang diproses.',
        'time': 'Selasa',
        'unread': '0',
        'image': 'assets/images/profile.png'
      },
    ];

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: maroonColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Chat',
          style: GoogleFonts.outfit(
            color: maroonColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert, color: maroonColor),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar di Chat
          Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: TextField(
                decoration: InputDecoration(
                  icon: const Icon(Icons.search, color: Colors.grey, size: 20),
                  hintText: 'Cari percakapan...',
                  hintStyle: GoogleFonts.outfit(color: Colors.grey, fontSize: 14),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),

          // List Chat
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: chats.length,
              separatorBuilder: (context, index) => const Divider(height: 1, color: Colors.black12),
              itemBuilder: (context, index) {
                final chat = chats[index];
                bool hasUnread = chat['unread'] != '0';

                return ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ChatDetailScreen(userName: chat['name']!),
                      ),
                    );
                  },
                  contentPadding: const EdgeInsets.symmetric(vertical: 8),
                  leading: CircleAvatar(
                    radius: 25,
                    backgroundImage: AssetImage(chat['image']!),
                  ),
                  title: Text(
                    chat['name']!,
                    style: GoogleFonts.outfit(
                      fontWeight: FontWeight.w700, // Lebih tebal (Bold)
                      fontSize: 16, // Lebih besar
                      color: Colors.black,
                    ),
                  ),
                  subtitle: Text(
                    chat['lastMessage']!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.outfit(
                      fontSize: 13,
                      color: hasUnread ? Colors.black87 : Colors.grey,
                    ),
                  ),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        chat['time']!,
                        style: GoogleFonts.outfit(fontSize: 11, color: Colors.grey),
                      ),
                      const SizedBox(height: 5),
                      if (hasUnread)
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: maroonColor,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            chat['unread']!,
                            style: const TextStyle(color: Colors.white, fontSize: 10),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
