class AddressData {
  static List<Map<String, dynamic>> addresses = [
    {
      'name': 'Vanya',
      'phone': '(+62) 812-3456-7890',
      'fullAddress': 'Jl.Mawar No. 20, RT 05/RW 07, Kel. Cempaka Putih, Muara Satu, Kota Lhokseumawe, DKI Jakarta\nMUARA SATU, KOTA LHOKSEUMAWE, NAGGROE ACEH DARUSSALAM, ID 12410',
      'isMain': true,
    },
  ];

  static void addAddress(Map<String, dynamic> newAddress) {
    // Jika disimpan sebagai utama, matikan alamat utama lainnya
    if (newAddress['isMain'] == true) {
      for (var addr in addresses) {
        addr['isMain'] = false;
      }
    }
    addresses.add(newAddress);
  }

  static void deleteAddress(int index) {
    if (index >= 0 && index < addresses.length) {
      addresses.removeAt(index);
    }
  }
}
