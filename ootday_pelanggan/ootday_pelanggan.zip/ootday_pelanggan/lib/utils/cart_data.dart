class CartData {
  static final List<Map<String, dynamic>> cartItems = [
    {
      'id': '1',
      'name': 'Elara side button',
      'desc': 'Warna: Putih, Ukuran: M',
      'price': 90000,
      'quantity': 1,
      'image': 'assets/images/kemeja_wanita/1.jpeg',
      'selected': true,
    },
    {
      'id': '2',
      'name': 'Blouse Putih Wanita',
      'desc': 'Warna: Hitam, Ukuran: L',
      'price': 89000,
      'quantity': 1,
      'image': 'assets/images/kemeja_wanita/2.jpeg',
      'selected': true,
    },
    {
      'id': '3',
      'name': 'Mocha knit tee',
      'desc': 'Warna: Denim, Ukuran: XL',
      'price': 90000,
      'quantity': 1,
      'image': 'assets/images/kemeja_wanita/3.jpeg',
      'selected': true,
    },
  ];

  static void addItem(Map<String, dynamic> item) {
    int index = cartItems.indexWhere((i) => i['name'] == item['name'] && i['desc'].contains(item['selectedColor']) && i['desc'].contains(item['selectedSize']));
    
    if (index != -1) {
      cartItems[index]['quantity'] += item['quantity'];
    } else {
      cartItems.add({
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'name': item['name'],
        'desc': 'Warna: ${item['selectedColor']}, Ukuran: ${item['selectedSize']}',
        'price': int.parse(item['price'].toString().replaceAll('.', '')),
        'quantity': item['quantity'],
        'image': item['image'],
        'selected': true,
      });
    }
  }
}
