class OrderData {
  static final List<Map<String, dynamic>> activeOrders = [
    {
      'id': 'ORD-12345',
      'status': 'Diproses',
      'store': 'Ootday Fashion Store',
      'items': [
        {
          'name': 'Wide Collar Drawstring Sleeve Blouse',
          'variant': 'Putih, M',
          'price': 95000,
          'quantity': 1,
          'image': 'assets/images/kemeja_wanita/3.jpeg',
        }
      ],
      'totalPrice': 95000,
      'paymentMethod': 'DANA',
      'orderTime': '11-10-2025 21:20',
    }
  ];

  static void addOrder(Map<String, dynamic> order) {
    activeOrders.add({
      'id': 'ORD-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
      'status': 'Diproses',
      'store': 'Ootday Fashion Store',
      ...order,
      'orderTime': DateTime.now().toString().substring(0, 16),
    });
  }
}
